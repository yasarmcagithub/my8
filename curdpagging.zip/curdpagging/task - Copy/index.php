<?php
// session_start();
// require_once('conn.php');
// session_start();
// $page=$_GET['page'];
// $_SESSION['page']=$page;
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" id="font-awesome-style-css" href="https://www.phpflow.com/code/css/bootstrap3.min.css" type="text/css" media="all">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagediv
		{
			margin-top: 20px;
			float: right;
			margin-right:50%; 
		}

	</style>
</head>
<body>
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a class="add_user" href="personal_detail.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<button class="search_btn" id="search_btn" name="search">Search</button>
	     </div>
	</div>

<div class="clear" >
	 

</div> 

 <div id="table">
 	<?php require_once('pagination.php'); ?>
 </div>
	
<script type="text/javascript">

	//SEARCH

	$(document).ready(function() {
    $("#search_btn").click(function(){ 
    var searchdata= $("#search_input").val();
	$.ajax({
    type: "POST",
    url: "search.php",
    data:{searchinfo:searchdata},
    dataType: "text",
    success: function(result) {
        $('#tabledata').html(result)
    }
    });
    });
    });

    //TABLE DATA

 //    $(document).ready(function() {
	// $.ajax({
 //    type: "post",
 //    url: "pagination.php",
 //    // data:{page:page},
 //    success: function(result) {
 //        $('#table').html(result)
 //    }
 //    });

 //    });


//  function getresult(url) {
// 	$.ajax({
// 		url: url,
// 		type: "GET",
// 		data:  {rowcount:$("#pagediv").val(),"pagination_setting":$("#pagination-setting").val()},
// 		success: function(data){
// 		$("#table").html(data);
// 		},
// 		error: function() 
// 		{} 	        
//    });
// }
// function changePagination(option) {
// 	if(option!= "") {
// 		getresult("pagination.php");
// 	}
// }



</script>
</body>
</html>