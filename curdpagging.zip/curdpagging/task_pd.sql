-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2020 at 10:16 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_pd`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `c_id` int(11) NOT NULL,
  `country_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`c_id`, `country_name`) VALUES
(1, 'USA'),
(2, 'India'),
(3, 'German');

-- --------------------------------------------------------

--
-- Table structure for table `personal_detail`
--

CREATE TABLE `personal_detail` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `mobile_no` bigint(20) DEFAULT NULL,
  `addr1` varchar(255) DEFAULT NULL,
  `addr2` varchar(255) DEFAULT NULL,
  `country` int(11) DEFAULT NULL,
  `state` tinyint(4) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `pincode` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `personal_detail`
--

INSERT INTO `personal_detail` (`id`, `first_name`, `last_name`, `email`, `gender`, `mobile_no`, `addr1`, `addr2`, `country`, `state`, `city`, `pincode`) VALUES
(1, 'yasar', 'arafath', 'redadzemedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'zxcxzc', 2, 5, 'vandavasi', 604408),
(2, 'yasar', 'arafath', 'redadzemedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'df', 2, 5, 'vandavasi', 604408),
(3, 'yasar', 'arafath', 'redadzemedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'zx', 2, 5, 'vandavasi', 604408),
(4, 'yasar', 'arafath', 'redadzemcxedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'zxz', 2, 5, 'vandavasi', 604408),
(5, 'yasar', 'arafath', 'redadzemsdedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'sd', 2, 5, 'vandavasi', 604408),
(6, 'faiyz', 'aBDUL', 'redadzemeassdia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'zxcc', 2, 5, 'vandavasi', 604408),
(7, 'yasar', 'arafath', 'redadzemxzcedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'zx', 2, 5, 'vandavasi', 604408),
(8, 'yasar', 'arafath', 'redadxzczemedia@gmail.com', 1, 8680989854, '18 kavaraistreet', 'zx', 2, 5, 'vandavasi', 604408),
(9, 'yasar', 'arafath', 'redadasxzczemedia@gmail.com', 2, 8680989854, '18 kavaraistreet', 'zxc', 2, 5, 'vandavasi', 604408),
(10, 'siva', 'saravanan', 'abc@gmail.com', 1, 124345, 'sadsd', 'zsd', 1, 1, 'das', 2324),
(11, 'srini', 'vasan', 'srini@gmail.com', 1, 7986530985, '13 pillayar street', 'tvm', 2, 2, 'palakadu', 2324),
(12, 'vijay', 'ka', 'asd@gmail.com', 1, 79865365985, '12/meener street', 'asd', 1, 2, 'florida', 2326),
(13, 'magesh', 'babu', 'mageshd@gmail.com', 1, 79865365985, '12/meener street', 'asd', 1, 2, 'florida', 2326),
(14, 'vijay', 'devarkonda', 'vijaydeverkondad@gmail.com', 1, 79865365985, '12/meener street', 'asd', 1, 2, 'florida', 2326),
(15, 'kamal', 'hasan', 'kamalhasan@gmail.com', 1, 79865365985, '12/meener street', 'asd', 1, 2, 'florida', 2326),
(16, 'ajith', 'kumar', 'ajithkumar@gmail.com', 1, 79865365985, '12/meener street', 'asd', 1, 2, 'florida', 2326),
(17, 'yasar', 'Arafath', 'arafath@gmail.com', 1, 7986530980, 'ads', 'klklllkk', 1, 2, 'sdsdd', 2324);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `s_id` int(11) NOT NULL,
  `c_id` int(11) DEFAULT NULL,
  `state_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`s_id`, `c_id`, `state_name`) VALUES
(1, 1, ' California'),
(2, 1, 'Washington'),
(3, 1, 'Texas'),
(4, 1, ' Florida'),
(5, 2, ' Tamilnadu'),
(6, 2, ' Kerala'),
(7, 2, ' Delhi'),
(8, 2, 'Kolkata'),
(9, 3, 'Berlin'),
(10, 3, 'Hamburg'),
(11, 3, 'Saxony');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `personal_detail`
--
ALTER TABLE `personal_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `personal_detail`
--
ALTER TABLE `personal_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
