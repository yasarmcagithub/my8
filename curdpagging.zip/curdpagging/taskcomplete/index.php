<?php
// session_start();
// require_once('conn.php');
// session_start();
// $page=$_GET['page'];
// $_SESSION['page']=$page;
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" id="font-awesome-style-css" href="https://www.phpflow.com/code/css/bootstrap3.min.css" type="text/css" media="all">
	<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>

	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.search_btn
		{
			padding: 5px 8px;
			cursor: pointer;
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }	

        #list th 
        {
          text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: center;
		  background-color: #4CAF50;
		  color: white;
		}
		.pagelist
		{
             text-decoration: none;
             background-color: #182c4d;
             color: white;
             padding: 3px 10px;
		}
		.pagediv
		{
			margin-top: 20px;
			float: right;
			margin-right:50%; 
		}

	</style>
</head>
<body>
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a class="add_user" href="personal_detail.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<button class="search_btn" id="search_btn" name="search">Search</button>
	     </div>
	</div>

<div class="clear" >
	 
</div> 

<div id="target-content" >loading...</div>
	
<script type="text/javascript">

$(document).ready(function() {

$("#target-content").load("pagination.php?page=1");
 //    $("#pagination li").live('click',function(e){
	// e.preventDefault();
	// 	$("#target-content").html('loading...');
	// 	$("#pagination li").removeClass('active');
	// 	$(this).addClass('active');
 //        var pageNum = this.id;
 //        var searchdata=$('#search_input').val();
 //        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata);
 //    });
 //     $("#search_btn").live('click',function(e){
	// e.preventDefault();
	// 	$("#target-content").html('loading...');
	// 	$("#pagination li").removeClass('active');
	// 	$(this).addClass('active');
 //        var pageNum = 1;
 //        var searchdata=$('#search_input').val();
 //        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata);

 //    });

     $(document).on('click','#search_btn',function(e){

     	e.preventDefault();
		$("#target-content").html('loading...');
		$("#pagination li").removeClass('active');
		$(this).addClass('active');
        var pageNum = 1;
        var searchdata=$('#search_input').val();
        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata);

     	
     });
       $(document).on('click','#pagination li',function(e){

     	e.preventDefault();
		$("#target-content").html('loading...');
		$("#pagination li").removeClass('active');
		$(this).addClass('active');
        var pageNum = this.id;
        var searchdata=$('#search_input').val();
        $("#target-content").load("pagination.php?page=" + pageNum + "&searchdata=" + searchdata);
        
     	
     });
    });

</script>
</body>
</html>