<?php
include('db.php');

$sql = "SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id";  
$rs_result = mysqli_query($conn, $sql);  
// echo $rs_result;
$row = mysqli_fetch_row($rs_result); 
// echo print_r($row); 
$total_records = $row[0];  
// echo "<br>". $total_records;
$total_pages = ceil($total_records / $limit); 

$limit = 5;  
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };  
$start_from = ($page-1) * $limit;  
  
$sql = "SELECT * FROM personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id LIMIT $start_from, $limit";  
$rs_result = mysqli_query($conn, $sql);  
echo print_r($rs_result);
?>
<table class="table table-bordered table-striped">  
<thead>  
<tr>  
<th>First Name</th>  
<th>Last Name</th>  
</tr>  
</thead>  
<tbody>  
<?php  
// while ($row = mysqli_fetch_row($rs_result)) {  
foreach ($rs_result as $row) {

?>  
            <tr>  
            <td><?php echo(isset($row['first_name'])?$row['first_name'] : "error");?></td>  
            <td><?php echo(isset($row['last_name'])?$row['last_name'] : "error"); ?></td>  
            </tr>  
<?php  
};  
?>  
</tbody>  
</table>    